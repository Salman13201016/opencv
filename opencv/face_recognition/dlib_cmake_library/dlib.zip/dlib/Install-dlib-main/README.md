# Install-dlib

### If you are installing dlib on <= python 3.6
Then follow below link for the whl file,
https://pypi.org/simple/dlib/

Complete video guide : https://youtu.be/ot6LWpZjTXo

### If you are installing dlib on python 3.7 or 3.8
Then download whl file from this repository and follow below episode to install it - https://youtu.be/AUJKdehF2ZA
